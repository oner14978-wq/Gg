package com.movtery.zalithlauncher

import android.content.Context
import android.media.MediaPlayer
import android.media.SoundPool

/** Efeitos sonoros e música de fundo do launcher (arquivos em res/raw). */
object SoundManager {
    private var pool: SoundPool? = null
    private var click = 0
    private var start = 0
    private var music: MediaPlayer? = null
    @Volatile var enabled = true

    fun init(context: Context) {
        if (pool != null) return
        val app = context.applicationContext
        pool = SoundPool.Builder().setMaxStreams(4).build().also {
            click = it.load(app, R.raw.ui_click, 1)
            start = it.load(app, R.raw.ui_start, 1)
        }
    }

    fun playClick() { if (enabled) pool?.play(click, 1f, 1f, 1, 0, 1f) }
    fun playStart() { if (enabled) pool?.play(start, 1f, 1f, 1, 0, 1f) }

    fun startMusic(context: Context) {
        if (!enabled || music != null) return
        music = MediaPlayer.create(context.applicationContext, R.raw.ui_music)?.apply {
            isLooping = true; setVolume(0.3f, 0.3f); start()
        }
    }

    fun stopMusic() { music?.release(); music = null }
}
