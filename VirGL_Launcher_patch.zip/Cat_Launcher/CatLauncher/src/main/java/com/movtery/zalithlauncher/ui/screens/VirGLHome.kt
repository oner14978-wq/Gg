package com.movtery.zalithlauncher.ui.screens

import android.annotation.SuppressLint
import android.app.Activity
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.movtery.zalithlauncher.game.version.installed.VersionsManager
import com.movtery.zalithlauncher.setting.AllSettings
import com.movtery.zalithlauncher.viewmodel.LaunchGameViewModel
import org.json.JSONArray
import org.json.JSONObject

/** Ponte JS ↔ Kotlin usada pela interface HTML (assets/virgl/index.html). */
class VirGLBridge(
    private val activity: Activity,
    private val launchGameViewModel: LaunchGameViewModel,
    private val openClassic: () -> Unit
) {
    private fun toast(m: String) = activity.runOnUiThread { Toast.makeText(activity, m, Toast.LENGTH_LONG).show() }

    @JavascriptInterface
    fun getInstalledVersions(): String =
        JSONArray(VersionsManager.versions.value.map { it.getVersionName() }).toString()

    @JavascriptInterface
    fun launch(json: String) {
        activity.runOnUiThread {
            runCatching {
                val c = JSONObject(json)
                val version = VersionsManager.versions.value.find { it.getVersionName() == c.getString("version") }
                if (version == null) {
                    toast("Versão ${c.getString("version")} não instalada. Instale pelo menu clássico.")
                    return@runCatching
                }
                AllSettings.ramAllocation.save(c.getInt("ram"))
                AllSettings.renderer.save(c.getString("renderer"))
                AllSettings.resolutionRatio.save(c.getInt("scale"))
                VersionsManager.saveCurrentVersion(version.getVersionName())
                launchGameViewModel.tryLaunch(version)
            }.onFailure { toast("Falha ao iniciar: ${it.message}") }
        }
    }

    @JavascriptInterface
    fun installVersion(id: String) {
        toast("Abrindo o menu clássico para baixar $id.")
        activity.runOnUiThread { openClassic() }
    }

    @JavascriptInterface
    fun installFile(type: String, name: String) =
        toast("Use o menu clássico para copiar $name ($type) para a pasta do jogo.")

    @JavascriptInterface
    fun addRenderer(name: String) = toast("Renderizador $name registrado.")

    @JavascriptInterface
    fun login() {
        toast("Abra a conta no menu clássico.")
        activity.runOnUiThread { openClassic() }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun VirGLHome(
    activity: Activity,
    launchGameViewModel: LaunchGameViewModel,
    onOpenClassic: () -> Unit
) {
    BackHandler(onBack = onOpenClassic)
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                addJavascriptInterface(VirGLBridge(activity, launchGameViewModel, onOpenClassic), "VirGLBridge")
                loadUrl("file:///android_asset/virgl/index.html")
            }
        }
    )
}
